
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, extract
from werkzeug.utils import secure_filename
import os, csv
from datetime import datetime, date
from calendar import monthrange

app = Flask(__name__)
app.secret_key = "dev-secret-change-me"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "gestioloc.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

db = SQLAlchemy(app)

# ----------------------
# Models
# ----------------------
class Projet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(200), nullable=False)
    budget_initial = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class TacheSuivi(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    statut = db.Column(db.String(20), default="A_FAIRE") # A_FAIRE, VALIDE, ANNULE
    date_creation = db.Column(db.Date, default=date.today)
    projet_id = db.Column(db.Integer, db.ForeignKey('projet.id'), nullable=False)

class ListeAchat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    montant_estime = db.Column(db.Float, default=0.0)
    projet_id = db.Column(db.Integer, db.ForeignKey('projet.id'), nullable=False)

class Depense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date_depense = db.Column(db.Date, nullable=False, default=date.today)
    description = db.Column(db.String(255), nullable=False)
    categorie = db.Column(db.String(120), default="Autre")
    montant = db.Column(db.Float, nullable=False, default=0.0)
    justificatif_path = db.Column(db.String(255), nullable=True)
    projet_id = db.Column(db.Integer, db.ForeignKey('projet.id'), nullable=False)

class Revenu(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    montant = db.Column(db.Float, nullable=False, default=0.0)
    date_debut = db.Column(db.Date, nullable=True)
    date_fin = db.Column(db.Date, nullable=True)
    date_recette = db.Column(db.Date, nullable=True)
    source = db.Column(db.String(120), default="Autre")
    projet_id = db.Column(db.Integer, db.ForeignKey('projet.id'), nullable=False)

class Charge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    montant = db.Column(db.Float, nullable=False, default=0.0)
    date_charge = db.Column(db.Date, nullable=True)  # pour ponctuelle
    type_charge = db.Column(db.String(20), default="ponctuelle")  # ponctuelle ou fixe
    frequence = db.Column(db.String(20), nullable=True)  # Mensuelle, Trimestrielle, Annuelle
    date_fin = db.Column(db.Date, nullable=True)  # fin de la récurrence
    projet_id = db.Column(db.Integer, db.ForeignKey('projet.id'), nullable=False)

# ----------------------
# Helpers
# ----------------------
def get_current_project():
    pid = session.get("projet_id")
    return Projet.query.get(pid) if pid else None

def month_nights(revenu: Revenu):
    if not revenu.date_debut or not revenu.date_fin:
        return 0
    delta = revenu.date_fin - revenu.date_debut
    return max(delta.days, 0)

def charges_for_month(year, month, projet_id):
    """Retourne la liste des charges (obj, montant) applicables pour le mois: ponctuelles du mois + récurrentes actives."""
    results = []
    # Ponctuelles du mois
    ponctuelles = Charge.query.filter(
        Charge.projet_id == projet_id,
        Charge.type_charge == 'ponctuelle',
        extract('year', Charge.date_charge) == year,
        extract('month', Charge.date_charge) == month
    ).all()
    for c in ponctuelles:
        results.append((c, c.montant))
    # Récurrentes
    rec = Charge.query.filter(
        Charge.projet_id == projet_id,
        Charge.type_charge == 'fixe'
    ).all()
    for c in rec:
        # La récurrence commence à date_charge et peut s'arrêter à date_fin
        start = c.date_charge or date(year, month, 1)
        if c.date_fin and date(year, month, monthrange(year, month)[1]) > c.date_fin:
            # ce mois finit après la date fin -> peut être inactif
            if date(year, month, 1) > c.date_fin:
                continue
        if date(year, month, 1) < start.replace(day=1):
            continue
        # Fréquence
        if c.frequence == 'Mensuelle':
            results.append((c, c.montant))
        elif c.frequence == 'Trimestrielle':
            # actif si (mois - mois de départ) % 3 == 0
            m0 = start.month
            if ((month - m0) % 3) == 0 and (year >= start.year):
                results.append((c, c.montant))
        elif c.frequence == 'Annuelle':
            if month == start.month:
                results.append((c, c.montant))
        else:
            # sécurité: si mal renseignée, on l'ignore
            pass
    return results

def month_metrics(year, month, projet_id):
    # Nuits
    revenus_m = Revenu.query.filter(
        Revenu.projet_id == projet_id,
        extract('year', Revenu.date_debut) == year,
        extract('month', Revenu.date_debut) == month
    ).all()
    nuits = sum(month_nights(r) for r in revenus_m)
    # Revenus
    revenus_total = db.session.query(func.sum(Revenu.montant)).filter(
        Revenu.projet_id == projet_id,
        extract('year', Revenu.date_debut) == year,
        extract('month', Revenu.date_debut) == month
    ).scalar() or 0.0
    # Charges
    charges_list = charges_for_month(year, month, projet_id)
    charges_total = sum(m for _, m in charges_list)
    adr = (revenus_total/nuits) if nuits > 0 else 0.0
    days_in_month = monthrange(year, month)[1]
    occupancy = (nuits / days_in_month) * 100 if days_in_month else 0.0
    cash_flow = revenus_total - charges_total
    return occupancy, adr, nuits, cash_flow

# ----------------------
# Init DB
# ----------------------
with app.app_context():
    db.create_all()

# ----------------------
# Routes - Projects
# ----------------------
@app.route('/projects', methods=['GET', 'POST'])
def projects():
    if request.method == 'POST':
        nom = request.form.get('nom', '').strip()
        budget = float(request.form.get('budget_initial', 0) or 0)
        if not nom:
            flash("Le nom du bien est obligatoire.", "warning")
        else:
            p = Projet(nom=nom, budget_initial=budget)
            db.session.add(p)
            db.session.commit()
            flash("Bien créé.", "success")
            return redirect(url_for('projects'))
    projets = Projet.query.order_by(Projet.id.desc()).all()
    return render_template('projects.html', projets=projets)

@app.route('/projects/select/<int:pid>')
def select_project(pid):
    if Projet.query.get(pid) is None:
        flash("Bien introuvable.", "warning")
        return redirect(url_for('projects'))
    session['projet_id'] = pid
    flash("Bien sélectionné.", "success")
    return redirect(url_for('dashboard'))

# ----------------------
# Home -> redirect
# ----------------------
@app.route('/')
def home():
    projet = get_current_project()
    if not projet:
        return redirect(url_for('projects'))
    return redirect(url_for('dashboard'))

# ----------------------
# Dashboard
# ----------------------
@app.route('/dashboard', methods=['GET'])
def dashboard():
    projet = get_current_project()
    if not projet:
        return redirect(url_for('projects'))

    # année sélectionnée
    try:
        selected_year = int(request.args.get('year', datetime.now().year))
    except:
        selected_year = datetime.now().year

    cy, cm = datetime.now().year, datetime.now().month

    occ_c, adr_c, nights_c, cf_c = month_metrics(cy, cm, projet.id)
    pm_year = cy if cm > 1 else cy-1
    pm_month = cm-1 if cm > 1 else 12
    occ_p, adr_p, nights_p, cf_p = month_metrics(pm_year, pm_month, projet.id)

    # moyenne glissante simple (36 derniers mois)
    months = []
    y, m = cy, cm
    for _ in range(36):
        months.append(month_metrics(y, m, projet.id))
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    if months:
        avg_occ = sum(x[0] for x in months) / len(months)
        avg_adr = sum(x[1] for x in months) / len(months)
    else:
        avg_occ = avg_adr = 0.0

    kpi_data = {
        "occupancy": {"current": round(occ_c,2), "previous": round(occ_p,2), "average": round(avg_occ,2)},
        "adr": {"current": round(adr_c,2), "previous": round(adr_p,2), "average": round(avg_adr,2)},
        "nights": {"current": int(nights_c), "previous": int(nights_p)}
    }

    nights_selected_year = [month_metrics(selected_year, m, projet.id)[2] for m in range(1,13)]
    nights_previous_year = [month_metrics(selected_year-1, m, projet.id)[2] for m in range(1,13)]
    cash_flow_selected_year = [month_metrics(selected_year, m, projet.id)[3] for m in range(1,13)]
    cash_flow_previous_year = [month_metrics(selected_year-1, m, projet.id)[3] for m in range(1,13)]

    # années disponibles (à partir des revenus et charges existants)
    years_revenus = [y for (y,) in db.session.query(extract('year', Revenu.date_debut)).filter(Revenu.projet_id==projet.id).distinct().all() if y]
    if not years_revenus:
        years_revenus = [cy]
    available_years = sorted(set(int(y) for y in years_revenus), reverse=True)

    return render_template('dashboard.html',
        projet=projet,
        kpi_data=kpi_data,
        available_years=available_years,
        selected_year=selected_year,
        nights_selected_year=nights_selected_year,
        nights_previous_year=nights_previous_year,
        cash_flow_selected_year=cash_flow_selected_year,
        cash_flow_previous_year=cash_flow_previous_year
    )

# ----------------------
# Travaux
# ----------------------
@app.route('/travaux', methods=['GET', 'POST'])
def travaux():
    projet = get_current_project()
    if not projet:
        return redirect(url_for('projects'))

    # Ajouts rapides
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add_previsionnel':
            desc = request.form.get('description'); montant = float(request.form.get('montant') or 0)
            db.session.add(ListeAchat(description=desc, montant_estime=montant, projet_id=projet.id))
            db.session.commit(); flash("Poste prévisionnel ajouté.", "success")
        elif action == 'add_depense':
            desc = request.form.get('description'); montant = float(request.form.get('montant') or 0)
            categorie = request.form.get('categorie') or 'Autre'
            d = request.form.get('date_depense') or date.today().isoformat()
            d = datetime.strptime(d, "%Y-%m-%d").date()
            justificatif = None
            if 'justificatif' in request.files and request.files['justificatif'].filename:
                f = request.files['justificatif']
                fname = secure_filename(f.filename)
                proj_dir = os.path.join(app.config['UPLOAD_FOLDER'], str(projet.id))
                os.makedirs(proj_dir, exist_ok=True)
                save_path = os.path.join(proj_dir, fname)
                f.save(save_path)
                justificatif = os.path.relpath(save_path, BASE_DIR)
            db.session.add(Depense(description=desc, montant=montant, categorie=categorie, date_depense=d,
                                   justificatif_path=justificatif, projet_id=projet.id))
            db.session.commit(); flash("Dépense ajoutée.", "success")
        elif action == 'add_tache':
            desc = request.form.get('description')
            db.session.add(TacheSuivi(description=desc, projet_id=projet.id))
            db.session.commit(); flash("Tâche ajoutée.", "success")
        elif action == 'set_budget':
            projet.budget_initial = float(request.form.get('budget_initial') or 0)
            db.session.commit(); flash("Budget mis à jour.", "success")
        return redirect(url_for('travaux'))

    previsionnels = ListeAchat.query.filter_by(projet_id=projet.id).all()
    depenses = Depense.query.filter_by(projet_id=projet.id).order_by(Depense.date_depense.desc()).all()
    taches = TacheSuivi.query.filter_by(projet_id=projet.id, statut="A_FAIRE").order_by(TacheSuivi.date_creation.desc()).all()

    depense_total = db.session.query(func.sum(Depense.montant)).filter(Depense.projet_id==projet.id).scalar() or 0.0
    prevision_total = db.session.query(func.sum(ListeAchat.montant_estime)).filter(ListeAchat.projet_id==projet.id).scalar() or 0.0
    engagement_total = depense_total + prevision_total
    reste = max(projet.budget_initial - engagement_total, 0.0)

    return render_template('travaux.html',
        projet=projet,
        depenses=depenses,
        previsionnels=previsionnels,
        taches=taches,
        kpis={
            "budget": round(projet.budget_initial,2),
            "depense": round(depense_total,2),
            "engagement": round(engagement_total,2),
            "reste": round(reste,2)
        }
    )

@app.route('/travaux/previsionnel/valider/<int:pid>')
def valider_previsionnel(pid):
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    item = ListeAchat.query.get_or_404(pid)
    if item.projet_id != projet.id:
        flash("Hors périmètre.", "warning"); return redirect(url_for('travaux'))
    # convertir en dépense
    dep = Depense(description=item.description, montant=item.montant_estime, categorie="Travaux",
                  date_depense=date.today(), projet_id=projet.id)
    db.session.add(dep); db.session.delete(item); db.session.commit()
    flash("Achat validé et converti en dépense.", "success")
    return redirect(url_for('travaux'))

@app.route('/travaux/previsionnel/delete/<int:pid>')
def delete_previsionnel(pid):
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    item = ListeAchat.query.get_or_404(pid)
    if item.projet_id != projet.id:
        flash("Hors périmètre.", "warning")
    else:
        db.session.delete(item); db.session.commit(); flash("Prévisionnel supprimé.", "success")
    return redirect(url_for('travaux'))

@app.route('/travaux/depense/delete/<int:did>')
def delete_depense(did):
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    d = Depense.query.get_or_404(did)
    if d.projet_id != projet.id:
        flash("Hors périmètre.", "warning")
    else:
        db.session.delete(d); db.session.commit(); flash("Dépense supprimée.", "success")
    return redirect(url_for('travaux'))

@app.route('/travaux/tache/<int:tid>/<action>')
def set_tache_status(tid, action):
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    t = TacheSuivi.query.get_or_404(tid)
    if t.projet_id != projet.id:
        flash("Hors périmètre.", "warning")
    else:
        if action == 'valider': t.statut = "VALIDE"
        elif action == 'annuler': t.statut = "ANNULE"
        db.session.commit(); flash("Tâche mise à jour.", "success")
    return redirect(url_for('travaux'))

@app.route('/uploads/<path:filepath>')
def serve_upload(filepath):
    # Security: only under uploads
    full = os.path.join(BASE_DIR, filepath)
    if not full.startswith(UPLOAD_FOLDER):
        flash("Accès fichier refusé.", "warning")
        return redirect(url_for('travaux'))
    return send_file(full, as_attachment=False)

# Zone de danger - purge des données du projet
@app.route('/travaux/danger/wipe', methods=['POST'])
def wipe_project():
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    # delete children
    Depense.query.filter_by(projet_id=projet.id).delete()
    ListeAchat.query.filter_by(projet_id=projet.id).delete()
    TacheSuivi.query.filter_by(projet_id=projet.id).delete()
    Revenu.query.filter_by(projet_id=projet.id).delete()
    Charge.query.filter_by(projet_id=projet.id).delete()
    db.session.commit()
    flash("Toutes les données de ce bien ont été supprimées.", "success")
    return redirect(url_for('travaux'))

# ----------------------
# Location
# ----------------------
@app.route('/location', methods=['GET', 'POST'])
def location():
    projet = get_current_project()
    if not projet:
        return redirect(url_for('projects'))

    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add_revenu':
            desc = request.form.get('description')
            montant = float(request.form.get('montant') or 0)
            date_debut = request.form.get('date_debut')
            date_fin = request.form.get('date_fin')
            date_recette = request.form.get('date_recette') or None
            source = request.form.get('source') or 'Autre'
            dd = datetime.strptime(date_debut, "%Y-%m-%d").date() if date_debut else None
            df = datetime.strptime(date_fin, "%Y-%m-%d").date() if date_fin else None
            dr = datetime.strptime(date_recette, "%Y-%m-%d").date() if date_recette else None
            db.session.add(Revenu(description=desc, montant=montant, date_debut=dd, date_fin=df,
                                  date_recette=dr, source=source, projet_id=projet.id))
            db.session.commit(); flash("Revenu ajouté.", "success")
        elif action == 'add_charge':
            desc = request.form.get('description')
            montant = float(request.form.get('montant') or 0)
            date_charge = request.form.get('date_charge') or None
            type_charge = request.form.get('type_charge') or 'ponctuelle'
            frequence = request.form.get('frequence') if type_charge == 'fixe' else None
            d = datetime.strptime(date_charge, "%Y-%m-%d").date() if date_charge else None
            db.session.add(Charge(description=desc, montant=montant, date_charge=d,
                                  type_charge=type_charge, frequence=frequence, projet_id=projet.id))
            db.session.commit(); flash("Charge ajoutée.", "success")
        elif action == 'import_airbnb':
            f = request.files.get('csv_airbnb')
            if f and f.filename:
                reader = csv.DictReader(f.stream.read().decode('utf-8').splitlines())
                inserted = 0; skipped = 0
                for row in reader:
                    # On suppose Airbnb export contient au moins start_date, amount
                    raw_start = row.get('start_date') or row.get('check_in') or row.get('Date début') or ""
                    raw_end = row.get('end_date') or row.get('check_out') or row.get('Date fin') or ""
                    raw_amount = row.get('amount') or row.get('payout') or row.get('Montant') or "0"
                    try:
                        dd = datetime.strptime(raw_start[:10], "%Y-%m-%d").date() if raw_start else None
                    except:
                        dd = None
                    try:
                        df = datetime.strptime(raw_end[:10], "%Y-%m-%d").date() if raw_end else None
                    except:
                        df = None
                    try:
                        montant = float(str(raw_amount).replace(',', '.'))
                    except:
                        montant = 0.0
                    # anti-doublon : même date_debut + montant
                    exists = Revenu.query.filter_by(projet_id=projet.id, date_debut=dd, montant=montant).first()
                    if exists:
                        skipped += 1; continue
                    db.session.add(Revenu(description=row.get('description') or 'Airbnb', montant=montant,
                                          date_debut=dd, date_fin=df, source='Airbnb', projet_id=projet.id))
                    inserted += 1
                db.session.commit()
                flash(f"Import Airbnb terminé: {inserted} lignes ajoutées, {skipped} doublons ignorés.", "success")
        return redirect(url_for('location'))

    # Filtre période
    y = int(request.args.get('year', datetime.now().year))
    m = int(request.args.get('month', datetime.now().month))

    revenus = Revenu.query.filter(
        Revenu.projet_id == projet.id,
        extract('year', Revenu.date_debut) == y,
        extract('month', Revenu.date_debut) == m
    ).order_by(Revenu.date_debut.desc()).all()

    charges_list = charges_for_month(y, m, projet.id)
    # Totaux
    total_rev = sum(r.montant for r in revenus)
    total_ch = sum(m for _, m in charges_list)

    # années dispo
    rev_years = [yr for (yr,) in db.session.query(extract('year', Revenu.date_debut)).filter(Revenu.projet_id==projet.id).distinct().all() if yr]
    ch_years = [yr for (yr,) in db.session.query(extract('year', Charge.date_charge)).filter(Charge.projet_id==projet.id).distinct().all() if yr]
    available_years = sorted(set(int(yr) for yr in (rev_years + ch_years if ch_years else rev_years)) or {y}, reverse=True)

    return render_template('location.html',
        projet=projet, year=y, month=m,
        available_years=available_years,
        revenus=revenus, charges_list=charges_list,
        totals={"revenus": round(total_rev,2), "charges": round(total_ch,2)}
    )

@app.route('/location/charge/<int:cid>/edit', methods=['GET', 'POST'])
def edit_charge(cid):
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    c = Charge.query.get_or_404(cid)
    if c.projet_id != projet.id:
        flash("Hors périmètre.", "warning")
        return redirect(url_for('location'))
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'end_recurrence':
            dt = request.form.get('date_fin')
            c.date_fin = datetime.strptime(dt, "%Y-%m-%d").date() if dt else date.today()
            db.session.commit(); flash("Récurrence clôturée.", "success")
        elif action == 'change_tarif':
            dt = request.form.get('date_debut_nv')
            nv_montant = float(request.form.get('montant_nv') or 0)
            # clôture à la veille
            c.date_fin = (datetime.strptime(dt, "%Y-%m-%d").date() if dt else date.today())
            db.session.commit()
            # nouvelle charge
            db.session.add(Charge(description=c.description, montant=nv_montant,
                                  date_charge=c.date_fin, type_charge='fixe', frequence=c.frequence,
                                  projet_id=projet.id))
            db.session.commit(); flash("Tarif modifié à partir de la date.", "success")
        return redirect(url_for('location'))
    return render_template('edit_charge.html', projet=projet, charge=c)

# ----------------------
# Export / Import Global CSV
# ----------------------
@app.route('/export_all')
def export_all():
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    out_path = os.path.join(BASE_DIR, f"export_projet_{projet.id}.csv")
    with open(out_path, "w", newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["Type","Date","Description","Montant","Categorie/Source/Type","Date Debut","Date Fin","Frequence"])
        # Depenses
        for d in Depense.query.filter_by(projet_id=projet.id).all():
            writer.writerow(["Depense_Travaux", d.date_depense.isoformat() if d.date_depense else "", d.description, d.montant, d.categorie, "", "", ""])
        # Previsionnel
        for p in ListeAchat.query.filter_by(projet_id=projet.id).all():
            writer.writerow(["Previsionnel_Travaux", "", p.description, p.montant_estime, "", "", "", ""])
        # Taches
        for t in TacheSuivi.query.filter_by(projet_id=projet.id).all():
            writer.writerow(["Tache", t.date_creation.isoformat() if t.date_creation else "", t.description, "", "", "", "", ""])
        # Revenus
        for r in Revenu.query.filter_by(projet_id=projet.id).all():
            writer.writerow(["Revenu", r.date_recette.isoformat() if r.date_recette else "", r.description, r.montant, r.source, r.date_debut.isoformat() if r.date_debut else "", r.date_fin.isoformat() if r.date_fin else "", ""])
        # Charges
        for c in Charge.query.filter_by(projet_id=projet.id).all():
            writer.writerow(["Charge", c.date_charge.isoformat() if c.date_charge else "", c.description, c.montant, c.type_charge, "", c.date_fin.isoformat() if c.date_fin else "", c.frequence or ""])
    return send_file(out_path, as_attachment=True, download_name=os.path.basename(out_path))

@app.route('/import_all', methods=['POST'])
def import_all():
    projet = get_current_project()
    if not projet: return redirect(url_for('projects'))
    f = request.files.get('csv_global')
    if not f or not f.filename:
        flash("Aucun fichier.", "warning"); return redirect(request.referrer or url_for('travaux'))
    try:
        reader = csv.DictReader(f.stream.read().decode('utf-8').splitlines())
        inserted = 0
        for row in reader:
            t = row.get('Type')
            if t == 'Depense_Travaux':
                d = datetime.strptime(row['Date'], '%Y-%m-%d').date() if row['Date'] else None
                db.session.add(Depense(description=row['Description'], montant=float(row['Montant'] or 0),
                                       categorie=row['Categorie/Source/Type'] or 'Autre',
                                       date_depense=d, projet_id=projet.id)); inserted += 1
            elif t == 'Previsionnel_Travaux':
                db.session.add(ListeAchat(description=row['Description'],
                                          montant_estime=float(row['Montant'] or 0),
                                          projet_id=projet.id)); inserted += 1
            elif t == 'Tache':
                d = datetime.strptime(row['Date'], '%Y-%m-%d').date() if row['Date'] else date.today()
                db.session.add(TacheSuivi(description=row['Description'], date_creation=d, projet_id=projet.id)); inserted += 1
            elif t == 'Revenu':
                dr = datetime.strptime(row['Date'], '%Y-%m-%d').date() if row['Date'] else None
                dd = datetime.strptime(row['Date Debut'], '%Y-%m-%d').date() if row['Date Debut'] else None
                df = datetime.strptime(row['Date Fin'], '%Y-%m-%d').date() if row['Date Fin'] else None
                db.session.add(Revenu(description=row['Description'], montant=float(row['Montant'] or 0),
                                      source=row['Categorie/Source/Type'] or 'Autre',
                                      date_recette=dr, date_debut=dd, date_fin=df, projet_id=projet.id)); inserted += 1
            elif t == 'Charge':
                d = datetime.strptime(row['Date'], '%Y-%m-%d').date() if row['Date'] else None
                df = datetime.strptime(row['Date Fin'], '%Y-%m-%d').date() if row['Date Fin'] else None
                db.session.add(Charge(description=row['Description'], montant=float(row['Montant'] or 0),
                                      date_charge=d, type_charge=row['Categorie/Source/Type'] or 'ponctuelle',
                                      frequence=(row['Frequence'] or None), date_fin=df, projet_id=projet.id)); inserted += 1
        db.session.commit()
        flash(f"Import terminé: {inserted} enregistrements ajoutés.", "success")
    except Exception as e:
        flash(f"Erreur import: {e}", "danger")
    return redirect(request.referrer or url_for('travaux'))

# ----------------------
# Utilities
# ----------------------
@app.template_filter("euro")
def euro_filter(val):
    try:
        return f"{float(val):,.2f} €".replace(",", " ").replace(".", ",")
    except:
        return f"{val} €"

# ----------------------
# Run
# ----------------------
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
