# GestioLoc Invest — Base propre

Application Flask + SQLite (SQLAlchemy) + Pico.css + Chart.js, multi-biens, modules Travaux / Location / Dashboard.
Uploads de justificatifs, import/export CSV, import Airbnb (anti-doublon).

## Lancer en local

```bash
python -m venv .venv && source .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
python app.py
# http://localhost:5000
```

## Variables / sécurité
- Change `app.secret_key` dans `app.py` (clé secrète de session).
- Les fichiers uploadés sont stockés par bien dans `uploads/<projet_id>/`.

## Docker

```bash
docker build -t gestioloc .
docker run -p 5000:5000 -v $(pwd)/uploads:/app/uploads gestioloc
# http://localhost:5000
```

## Structure
- `app.py` : app Flask + routes + modèles
- `templates/` : `_layout.html`, `projects.html`, `dashboard.html`, `travaux.html`, `location.html`, `edit_charge.html`
- `uploads/` : justificatifs (créé au run)
- `static/` : (optionnel, CDN par défaut)

## Import CSV Airbnb
Le parse tente `start_date`/`check_in` + `amount` (`payout`). Doublons ignorés sur `(date_debut, montant)`.

## Export/Import global CSV
Format unique (Type / Date / Description / Montant / Categorie/Source/Type / Date Debut / Date Fin / Frequence).
